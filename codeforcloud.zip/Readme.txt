In the directroy, there are three master files, two worker files, two client files, three demomaster for presenting the protocol between masters, one router file, a game file, and two html files and one css file.

master1.js, master2.js, master3.js are three masters in one group, worker1.js represents a worker in group one, worker2.js represents a worker in group two, client1.js is for clients in group one, client2.js is for clients in group two, index1.html is for game rendering for clients in group one, index2.html is for game rendering in group two, masterprotocol.js and masterprotocol2.js and masterprotocol3.js are for demoing the protocol between masters in the same group.

Thanks for reading.

